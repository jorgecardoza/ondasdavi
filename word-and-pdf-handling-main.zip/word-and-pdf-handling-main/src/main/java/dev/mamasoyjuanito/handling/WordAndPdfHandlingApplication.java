package dev.mamasoyjuanito.handling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordAndPdfHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordAndPdfHandlingApplication.class, args);
	}

}
