package dev.mamasoyjuanito.utils;

public class Constantes {

	public static final String EXTENSION_DOCX = "docx";
	public static final String EXTENSION_PDF = "pdf";
	
}
