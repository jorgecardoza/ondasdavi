# word-and-pdf-handling
Proyecto para manipular archivos Word y convertirlos a PDF

### Pre-requisitos 📋
* Java 8 
* Maven

Es un proyecto de Spring boot, solo contiene dos clases, una para el manejo del archivo Word y la otra para la conversión a PDF. 

La manipulación del archivo word es para reemplazar textos a traves de un identificaro, por ejemplo $nombreKey ó {{nombreKey}}.